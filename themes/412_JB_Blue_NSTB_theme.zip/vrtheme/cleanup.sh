#!/sbin/sh
rm -rf /sdcard/vrtheme/
echo "Cleanup complete"
