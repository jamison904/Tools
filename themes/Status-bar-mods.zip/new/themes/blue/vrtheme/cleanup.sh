#!/sbin/sh
rm -rf /cache/vrtheme/
echo "Cleanup complete"
