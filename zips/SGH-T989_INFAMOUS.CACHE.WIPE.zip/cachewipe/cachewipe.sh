#!/sbin/sh
 
sync;
/sbin/umount /cache

/tmp/cachewipe/mkfs.ext4 -t ext4 -b 4096 -m 0 -F -L userdata /dev/block/mmcblk0p26
/tmp/cachewipe/tune2fs -o journal_data_ordered /dev/block/mmcblk0p26
/tmp/cachewipe/tune2fs -E hash_alg=tea /dev/block/mmcblk0p26
/tmp/cachewipe/tune2fs -e continue /dev/block/mmcblk0p26
/tmp/cachewipe/e2fsck /dev/block/mmcblk0p26
/tmp/cachewipe/e2fsck -yf /dev/block/mmcblk0p26

sync;
rm -r /tmp/cachewipe;
sync;
