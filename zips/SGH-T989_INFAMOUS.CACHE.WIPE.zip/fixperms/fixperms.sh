#!/sbin/sh

sh /sbin/fix_permissions -r
sync;
